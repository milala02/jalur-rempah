export * from './worker.js';

export const WORKER_APP_NAME = '@jalur-rempah/worker';
