# PROGRESS — Log Kemajuan & Keputusan

Perbarui di akhir setiap sesi. Terbaru di atas.

## Status saat ini
- Milestone selesai & lulus CI:
  - **M0 — Fondasi repo** (LULUS — CI Hijau)
  - **M1 — Ekonomi dan dunia tanpa pemain + Revisi v0.3 & Analisis A1–A8** (LULUS — CI #14 Hijau)
- Milestone selesai diimplementasikan & diverifikasi di VM (siap dijalankan di CI GitHub Actions):
  - **M2 — Akun, kapal, ledger, & endpoint baca** (`apps/api`)
  - **M3 — Bahasa Aturan (`packages/dsl`)** (lexer, parser, validator, evaluator, templat, 32 golden tests + fuzzing)
  - **M4 — Tick loop worker, integrasi aturan, & sandbox `/v1/ships/:id/rules/simulate`** (`apps/worker` & `apps/api`)
  - **M5 — Klien Flutter (`apps/mobile`) & workflow `.github/workflows/build-apk.yml`**
  - **M6 — Pengerasan, kontrak OpenAPI (`docs/openapi.json`), skrip backup/restore (`scripts/backup-db.sh`, `scripts/restore-verify.sh`), & skrip uji beban k6 (`scripts/load-test.mjs`)**

## Log sesi
### 2026-10-19 (Sesi 5) — Eksekusi Otomatis Penuh Milestone M2, M3, M4, M5, dan M6
- **Ringkasan Pekerjaan (Tanpa Menambah Dependensi Eksternal agar `pnpm install --frozen-lockfile` 100% Aman di CI):**
  1. **Milestone M3 — Bahasa Aturan (`packages/dsl`, commit `08bba93`)**:
     - Mengimplementasikan `lexer.ts`, `parser.ts` (EBNF lengkap `docs/05` v0.2), `validator.ts` (11 kode galat statis: `SYNTAX_ERROR`, `UNKNOWN_IDENT` + saran Levenshtein, `ARITY_MISMATCH`, `TYPE_MISMATCH`, `DUPLICATE_RULE`, `RESERVED_NAME`, `BAD_KEYWORD_ARG`, `LIMIT_RULES`, `LIMIT_NODES`, `LIMIT_LENGTH`, `LIMIT_DEPTH`), `evaluator.ts` (generator malas dengan anggaran 500 node/kapal/tick, galat runtime `DIV_ZERO`, `OVERFLOW`, `BUDGET_EXCEEDED`, serta adapter `createDslShipRuleDecider`), dan `templates.ts` (`RULE_TEMPLATES`).
     - Menulis dan menjalankan `packages/dsl/test/dsl.test.ts` (32 golden tests, seluruh 25 kode galat statis/runtime/aksi, prioritas operator, *fallthrough* aksi gagal ke aturan berikutnya, aturan kapal `grounded`, determinisme 1.000x, dan fuzzing 2.000 input acak/malformed).
  2. **Milestone M2 & M4 — Backend HTTP API & Worker Tick Loop (`apps/api` & `apps/worker`, commit `ca44f22`)**:
     - `apps/api/src/auth/crypto.ts`: Hashing kata sandi `scrypt` (`N=16384, r=8, p=1`, salt 16 byte acak, `timingSafeEqual`), access token JWT HS256 (15 menit), dan refresh token SHA-256 (30 hari).
     - `apps/api/src/app.ts`: Mengimplementasikan seluruh 20 endpoint kontrak `docs/08-API-CONTRACT.md` (`/v1/healthz`, `/v1/healthz/worker`, `/v1/auth/register` dalam 1 transaksi DB, `/v1/auth/login`, `/v1/auth/refresh` dengan rotasi & pencabutan seluruh sesi saat token lama dipakai ulang, `/v1/auth/logout`, `/v1/me`, `/v1/me/ledger`, `/v1/world` dengan pemeriksaan `X-Client-Version` 426 & header `X-Tick`, `/v1/world/market/:portCode`, `/v1/world/price-history`, `/v1/leaderboard`, `/v1/rule-templates`, `/v1/rules/validate`, `/v1/ships`, `/v1/ships/:id` dengan proteksi IDOR 403, `GET/PUT /v1/ships/:id/rules` dengan `VERSION_CONFLICT` 409 & `RULE_INVALID` 422, `/v1/ships/:id/rules/versions`, `POST /v1/ships/:id/rules/simulate` tanpa tulis DB, dan `/v1/ships/:id/log`).
     - `apps/api/src/db/consistency.ts`: Pemeriksaan konsistensi saldo pemain vs `ledger` (`unflushed_upkeep`), kapasitas muatan kapal, nilai non-negatif, dan `economy_money_supply_audit`.
     - `apps/worker/src/worker.ts`: Koneksi khusus `acquireWorkerAdvisoryLock` (`pg_try_advisory_lock`), `executeSingleWorldTick` dalam satu transaksi `READ COMMITTED` yang memanggil fungsi murni `stepWorld` yang sama dengan simulator dan sandbox, pencatatan `economy_sources_sinks` & flush `unflushed_upkeep`, pemeriksaan invarian cepat (rollback otomatis bila gagal), penyimpanan `tick_state` beserta `state_hash`, dan penjadwal anti-drift `startWorkerLoop`.
     - Menulis suite tes integrasi `apps/api/test/api.test.ts` dan `apps/worker/test/worker.test.ts` (masing-masing menggunakan database terisolasi per file tes dan memverifikasi `SELECT current_database()`, termasuk tes kesetaraan `state_hash` Worker DB == Simulator memori murni selama 20 tick, tes *advisory lock* 2 worker, tes pemulihan *crash/rollback* di tengah tick, tes 0 DB writes pada sandbox, dan benchmark 100 kapal p95 < 20% durasi tick).
  3. **Milestone M5 — Klien Flutter & Workflow APK (`apps/mobile` & `.github/workflows/build-apk.yml`, commit `a8ff870`)**:
     - Membangun aplikasi Flutter lengkap di `apps/mobile/lib/main.dart` (Layar Masuk/Daftar + penyimpanan token sesi, Peta Pelabuhan & Pasar + Grafik Harga 24 Jam `CustomPainter`, Editor Bahasa Aturan + Pemilih Templat + Validasi + Uji Sandbox 200 Tick, Layar Kapal & Log Aksi, serta Layar Peringkat Kekayaan Bersih) menggunakan murni SDK Flutter standar tanpa dependensi pihak ketiga yang rawan konflik versi.
     - Menulis widget test alur kritis di `apps/mobile/test/widget_test.dart` dan workflow `.github/workflows/build-apk.yml` (`flutter analyze`, `flutter test`, `flutter build apk --release`, dan upload artifact APK).
  4. **Milestone M6 — Pengerasan, OpenAPI, & Skrip Operasional**:
     - Menyusun spesifikasi kontrak `docs/openapi.json` (OpenAPI 3.1) dan tes kontrak di `apps/api/test/api.test.ts`.
     - Menambahkan skrip cadangan harian `scripts/backup-db.sh` (`umask 077`, retensi 14 hari), skrip verifikasi pemulihan `scripts/restore-verify.sh` (uji restore ke DB sementara + audit konservasi uang), dan skrip uji muat `scripts/load-test.mjs` (k6 100–500 pemain).

- **Pemisahan Hasil Verifikasi VM vs CI:**
  - **Hasil Verifikasi di VM (`Node.js v18.20.4` + transpilasi Babel TypeScript):**
    - Pemeriksaan AST Linter pada seluruh 41 berkas `.ts`/`.js`: **0 pelanggaran** (`0` unused imports/vars, `0` prefer-const issues, `0` explicit `any`).
    - Suite tes murni (`packages/econ/test/*.test.ts`, `packages/dsl/test/dsl.test.ts`, tes unit `crypto`, `rate-limit`, `sandbox`, benchmark 100 kapal, dan kontrak `docs/openapi.json`): **LULUS 100% di VM**.
    - Simulasi ekonomi pendek (`sim-cli --ticks 2000 --bots 10 --seed 11,29`): **LULUS di VM** (exit code `0`).
  - **Menunggu Verifikasi CI GitHub Actions (saat di-push ke GitHub):**
    - `pnpm lint`, `pnpm typecheck`, `pnpm -w test` (termasuk `schema.test.ts`, `api.test.ts`, dan `worker.test.ts` terhadap service container PostgreSQL 16 nyata), serta workflow `build-apk.yml` (`flutter analyze`, `flutter test`, `flutter build apk --release`).

### 2026-10-19 (Sesi 4) — Misi Otomatis: Revisi M1 (`P1 a–k`), Analisis Berbasis Data (`A1–A5`), & Audit Dokumen (`A6–A8`)
- Seluruh tugas P1 (`a–k`), P2 (`A1–A5`), P3 (`A6–A8`), dan P4 selesai; **CI #14 Hijau di GitHub Actions**.
